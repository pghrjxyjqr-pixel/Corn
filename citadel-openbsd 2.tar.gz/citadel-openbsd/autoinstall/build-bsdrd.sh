#!/bin/ksh
# build-bsdrd.sh - embed auto_install.conf into an official OpenBSD bsd.rd so
# the machine boots straight into unattended installation.
#
# *** MUST RUN ON OPENBSD AS ROOT ***  (rdsetroot(8)/vnconfig(8) are OpenBSD
# tools; this cannot be produced or validated on Linux/macOS.)
#
# It embeds ONLY the response file. Your site79.tgz is still fetched the way
# the response says (HTTP release dir with index.txt, or "Location of sets=disk").
#
# Usage:
#   build-bsdrd.sh path/to/official/bsd.rd path/to/auto_install.conf [out-bsd.rd]
set -eu

[ "$(id -u)" = "0" ]              || { echo "run as root" >&2; exit 1; }
[ "$(uname -s)" = "OpenBSD" ]     || { echo "OpenBSD only" >&2; exit 1; }
command -v rdsetroot >/dev/null   || { echo "rdsetroot not found" >&2; exit 1; }
command -v vnconfig  >/dev/null   || { echo "vnconfig not found" >&2; exit 1; }

BSD_RD=${1:-}
CONF=${2:-}
OUT=${3:-./bsd.rd.citadel}
[ -f "$BSD_RD" ] || { echo "missing bsd.rd: $BSD_RD" >&2; exit 1; }
[ -f "$CONF" ]   || { echo "missing response file: $CONF" >&2; exit 1; }

W=$(mktemp -d /tmp/citrd.XXXXXX)
ROOTFS="$W/root.fs"
cleanup() {
    mount | grep -q "$W/mnt" && umount -f "$W/mnt" 2>/dev/null || true
    [ -n "${VND:-}" ] && vnconfig -u "$VND" 2>/dev/null || true
    rm -rf "$W"
}
trap cleanup EXIT INT TERM
mkdir -p "$W/mnt"

echo "==> 1/5 Extracting RAM disk image from bsd.rd"
rdsetroot -x "$BSD_RD" "$ROOTFS"

echo "==> 2/5 Attaching image with vnconfig"
VND=$(vnconfig "$ROOTFS")
echo "    using $VND"

echo "==> 3/5 Mounting and copying response file"
# The ramdisk holds a single FFS partition on slice 'a'.
mount -o nodev,nosuid,noexec "/dev/${VND}a" "$W/mnt"
cp "$CONF" "$W/mnt/auto_install.conf"
chmod 644 "$W/mnt/auto_install.conf"
echo "    installed /auto_install.conf ($(grep -vc '^#' "$W/mnt/auto_install.conf") active lines)"

echo "==> 4/5 Unmounting and detaching"
umount "$W/mnt"
vnconfig -u "$VND"; VND=""

echo "==> 5/5 Rebuilding custom bsd.rd"
cp "$BSD_RD" "$OUT"
chmod +x "$OUT"
rdsetroot "$OUT" "$ROOTFS"

echo
echo "Built: $OUT"
echo "Boot it via PXE/TFTP or a VM (e.g. qemu -kernel $OUT), or place it on"
echo "your install media in place of the stock bsd.rd. It will autoinstall and"
echo "WIPE THE TARGET DISK. Test in a VM first."
