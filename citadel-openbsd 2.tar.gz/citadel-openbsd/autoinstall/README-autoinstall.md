# OpenBSD 自动安装集成（装完即带 Citadel 基线）

这套东西把 Citadel 焊进 OpenBSD 的**官方安装流程**，不用装完系统再手工上传脚本：

- `auto_install.conf.template` — 无人值守应答文件（自动分区、建用户、装公钥、拉取 file sets）。
- `install.site.sh` — 打包成 `/install.site`，安装器在新系统 chroot 里执行，登记**首次启动**任务。
- `build-siteset.sh` — 生成官方自定义文件集 **site79.tgz**（Linux/macOS/OpenBSD 都能跑）。
- `build-bsdrd.sh` — 在一台 **OpenBSD** 上把应答文件嵌进官方 `bsd.rd`，引导即自动安装。

> 机制依据（OpenBSD 官方）：`autoinstall(8)`、`install.site(5)`、`faq4.html` 的
> “site79.tgz 文件集”、`rdsetroot(8)`、`vnconfig(8)`。

## 装完后系统处于什么状态

- Citadel 安装在 **`/opt/citadel`**。
- **首次启动自动应用“不会锁死”的基线**：sysctl 内核加固、服务最小化、doas、ntpd TLS 约束；
  日志 `/var/log/citadel-firstboot.log`，完成后落 `/var/citadel-firstboot.done`。
- **防火墙 pf 与 SSH 锁定不在安装/首启时自动做**——这两步可能把人挡在外面，
  必须等你确认控制台、SSH 公钥、管理白名单后，登录进去交互执行（脚本自带
  180 秒失联回滚）。首启后提示在 `/root/CITADEL_NEXT_STEPS.txt`。

## 路径 A：HTTP/PXE 无人值守（适合批量、虚拟化）

1. 在一台发布机准备目录，放入**官方 7.9 全套 sets** 和你的 `site79.tgz`：
   ```
   /var/pub/openbsd/7.9/amd64/   # base79.tgz etc. + site79.tgz
   ```
2. **在 OpenBSD 上**重建索引（site set 必须进 `index.txt`，且格式是 OpenBSD 的 `ls -lT`）：
   ```sh
   cd /var/pub/openbsd/7.9/amd64
   ls -lT > index.txt
   ```
   用任意 HTTP 服务（OpenBSD base 的 `httpd` 即可）发布该目录。
3. 复制并编辑应答文件，放到 Web 根，命名 `install.conf`（或按 MAC/主机名命名）：
   ```sh
   cp auto_install.conf.template install.conf
   vi install.conf     # 网卡、磁盘、ADMIN 用户、公钥、HTTP Server/目录
   ```
   DHCP/TFTP 让机器走 autoinstall（`filename "auto_install";` 指向 next-server），
   或引导 `bsd.rd` 后选 **(A)utoinstall**。

## 路径 B：应答文件内嵌进 bsd.rd（离线 U 盘 / 虚拟镜像）

1. 先生成 site set（任意系统）：
   ```sh
   ADMIN_USER=ops EXT_IF=em0 MGMT_CIDRS="203.0.113.10/32" \
       PUBLIC_TCP_PORTS="80 443" ./build-siteset.sh
   # 产物：dist/site79.tgz
   ```
2. **在一台 OpenBSD 上**（`rdsetroot/vnconfig` 只有 OpenBSD 有）：
   ```sh
   # 先从镜像取得与目标同版本同架构的官方 bsd.rd
   ./build-bsdrd.sh bsd.rd auto_install.conf bsd.rd.citadel
   ```
   生成的 `bsd.rd.citadel` 引导即自动安装。它内嵌的是**应答文件**；
   site79.tgz 仍按应答里的 `Location of sets` 获取（HTTP 或 disk）。
3. **完全离线 U 盘**：把官方 sets 与 `site79.tgz` 放同一 U 盘目录，应答里用
   `Location of sets = disk`（模板末尾有注释段），安装器从该盘选 `site79.tgz`。

> 把定制 `bsd.rd` 重新封进可引导 ISO/IMG 的步骤依赖 `mkhybrid`/发行版镜像布局，
> 且必须在 OpenBSD 上完成并真机验证——本工具不替你生成最终 ISO。

## 应答文件必须改的项（否则不会按你的机器装）

| 字段 | 说明 |
|---|---|
| `Which network interface ...` | 真实网卡名（物理机常 `em0`，virtio 常 `vio0`，用 `ifconfig` 查） |
| `Setup a user` / `Public ssh key for ...` | 该用户必须与 site set 里的 `ADMIN_USER` **一致**，且是 wheel 成员 |
| `Password for root/user` | `*************`（13 个星号）表示**禁用密码、仅密钥** |
| `Which disk is the root disk` | 目标盘（`sd0` / `virtio` 常 `vd0`）——**整盘会被清空** |
| `HTTP Server` / `Server directory` | 你放官方 sets + site79.tgz + index.txt 的位置 |
| `Set name(s)` | 已含 `site79.tgz`，并按服务器需要裁剪了 x11/game 等集 |

未命中的问题一律走安装器默认值；应答支持“问题的无歧义子串”匹配。

## 上线前验证清单（务必）

1. **先在一次性虚拟机里完整跑一遍**自动安装，确认磁盘没选错、用户/密钥可登录。
2. 装完检查：`ls /opt/citadel`、`cat /var/log/citadel-firstboot.log`、
   `cat /root/CITADEL_NEXT_STEPS.txt`。
3. 登录后再交互执行 `bin/citadel.sh pf`（新会话 `pf confirm`）、`ssh`、`audit`，
   全程保留控制台，见上级 `docs/RECOVERY.md`。

## 安全提醒

- 无人值守安装**无二次确认地抹掉整盘**，应答文件里的磁盘名务必正确。
- 禁用密码前，应答里的公钥必须真实可用，否则装完只能走控制台。
- site79.tgz 用 `tar -xzphf` 解包（保留权限/属主），构建来源要可信。
