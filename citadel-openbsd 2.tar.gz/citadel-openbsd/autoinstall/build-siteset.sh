#!/bin/sh
# build-siteset.sh - assemble OpenBSD site79.tgz containing Citadel.
# Runs on Linux/macOS OR OpenBSD (needs only: cp, sed, tar, mkdir, chmod).
#
# The resulting archive is rooted at / and carries:
#   /install.site        (executable post-install hook)
#   /opt/citadel/...     (the whole kit, with a pre-rendered site.conf)
#
# Override defaults via environment, e.g.:
#   ADMIN_USER=ops MGMT_CIDRS="203.0.113.10/32" ./build-siteset.sh
set -eu

HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
KIT=$(CDPATH= cd -- "$HERE/.." && pwd)            # .../citadel-openbsd
OUT="${OUT:-$HERE/dist}"

ADMIN_USER="${ADMIN_USER:-admin}"
EXT_IF="${EXT_IF:-em0}"
SSH_PORT="${SSH_PORT:-22}"
MGMT_CIDRS="${MGMT_CIDRS:-203.0.113.10/32}"
PUBLIC_TCP_PORTS="${PUBLIC_TCP_PORTS:-}"
ALLOW_OUTBOUND_BASIC="${ALLOW_OUTBOUND_BASIC:-1}"
NTP_CONSTRAINT_URL="${NTP_CONSTRAINT_URL:-https://www.openbsd.org/}"

WORK=$(mktemp -d 2>/dev/null || mktemp -d -t citsite)
trap 'rm -rf "$WORK"' EXIT INT TERM
STAGE="$WORK/root"

echo "==> Staging kit at \$ROOT/opt/citadel"
mkdir -p "$STAGE/opt"
cp -R "$KIT" "$STAGE/opt/citadel"
# Do not ship our build output or a stale site.conf inside the set.
rm -rf "$STAGE/opt/citadel/autoinstall/dist"
rm -f  "$STAGE/opt/citadel/site.conf"

echo "==> Rendering /opt/citadel/site.conf"
cfg="$STAGE/opt/citadel/site.conf"
cp "$STAGE/opt/citadel/site.conf.example" "$cfg"
set_conf() { # key value
    _k=$1; shift; _v=$*
    # Replace an existing KEY=... line; value is single-quoted, escape quotes.
    _ve=$(printf '%s' "$_v" | sed "s/'/'\\\\''/g")
    sed -i "s|^$_k=.*|$_k='$_ve'|" "$cfg"
}
set_conf EXT_IF "$EXT_IF"
set_conf SSH_PORT "$SSH_PORT"
set_conf ADMIN_USER "$ADMIN_USER"
set_conf MGMT_CIDRS "$MGMT_CIDRS"
set_conf PUBLIC_TCP_PORTS "$PUBLIC_TCP_PORTS"
set_conf ALLOW_OUTBOUND_BASIC "$ALLOW_OUTBOUND_BASIC"
set_conf NTP_CONSTRAINT_URL "$NTP_CONSTRAINT_URL"
# pf is NOT run automatically at first boot; keep the out-of-band gate at "no"
# until the admin is physically ready.
set_conf CONFIRM_OUT_OF_BAND "no"
set_conf ENABLE_SECURELEVEL2 "no"
chmod 600 "$cfg"

echo "==> Installing executable /install.site hook"
cp "$HERE/install.site.sh" "$STAGE/install.site"
chmod 755 "$STAGE/install.site"
sh -n "$STAGE/install.site" || { echo "install.site syntax error" >&2; exit 1; }

echo "==> Building site79.tgz (rooted at /)"
mkdir -p "$OUT"
# -h follows symlinks (matches the official `tar -czhf` site-set convention).
( cd "$STAGE" && tar -czhf "$OUT/site79.tgz" . )

# index.txt is required ONLY for HTTP(S) delivery and must be produced by
# OpenBSD `ls -lT` (its timestamp format is what the installer parses).
if ls -lT "$OUT/site79.tgz" >/dev/null 2>&1; then
    ( cd "$OUT" && ls -lT > index.txt )
    echo "==> Wrote $OUT/index.txt (OpenBSD ls -lT format)"
else
    echo "    NOTE: this host lacks OpenBSD 'ls -T'. On your OpenBSD HTTP"
    echo "    release dir, after placing the file run:  ls -lT > index.txt"
fi

echo
echo "==> Archive layout (paths are relative to the new system's /):"
tar tzf "$OUT/site79.tgz" | grep -E '(^\./install\.site$|citadel/bin/citadel\.sh|citadel/site\.conf$)' | sed 's#^#    #'
echo
echo "Built: $OUT/site79.tgz ($(wc -c < "$OUT/site79.tgz") bytes)"
echo "Next: see $HERE/README-autoinstall.md (HTTP/PXE, USB, or custom bsd.rd)."
