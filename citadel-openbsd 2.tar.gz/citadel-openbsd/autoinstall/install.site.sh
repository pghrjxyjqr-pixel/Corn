#!/bin/sh
# /install.site - runs INSIDE the freshly installed system (chroot at its /)
# at the end of the OpenBSD installer, before the first reboot.
#
# It is delivered by site79.tgz, which already placed the kit at /opt/citadel.
# Design rule: do NOT touch pf/sshd here or at first boot - those two can lock
# you out and must run after you have confirmed console + key + allowlist.
# Here we only register a one-shot FIRST-BOOT job that applies the non-lockout
# baseline (sysctls, service minimisation, doas, ntpd) and prints next steps.
set -u
PATH=/bin:/usr/bin:/sbin:/usr/sbin:/opt/citadel/bin
LOG=/citadel-install.log
CIT=/opt/citadel

{
echo "=== install.site started $(date) ==="

if [ ! -d "$CIT/bin" ]; then
    echo "ERROR: $CIT missing - was site79.tgz built correctly?"
    exit 0   # never abort the OS install over a site-set problem
fi

# Ownership/perms (tar -xzphf already preserves them, this is belt-and-braces).
chown -R root:wheel "$CIT" 2>/dev/null || true
chmod 755 "$CIT"/bin/*.sh "$CIT"/tools/*.sh 2>/dev/null || true
[ -f "$CIT/site.conf" ] || cp "$CIT/site.conf.example" "$CIT/site.conf"

# ---- one-shot first-boot block (idempotent markers) ----------------------
if ! grep -q 'BEGIN citadel-firstboot' /etc/rc.firsttime 2>/dev/null; then
    cat >> /etc/rc.firsttime <<'FIRSTBOOT'

# ----- BEGIN citadel-firstboot (managed by Citadel, do not hand-edit) -----
if [ -x /opt/citadel/bin/citadel.sh ] && [ ! -f /var/citadel-firstboot.done ]; then
    {
        echo "=== Citadel first-boot $(date) ==="
        /opt/citadel/bin/citadel.sh check || true
        # Non-lockout baseline only. pf/ssh are applied later by the admin.
        /opt/citadel/bin/citadel.sh system || true
        echo
        echo "Citadel baseline applied. Remaining (after console + key verified):"
        echo "  cd /opt/citadel && bin/citadel.sh pf   # then: bin/citadel.sh pf confirm"
        echo "                       bin/citadel.sh ssh  # verify a NEW key login"
        echo "                       bin/citadel.sh audit"
        echo "See /opt/citadel/docs/RECOVERY.md before the pf step."
    } > /var/log/citadel-firstboot.log 2>&1
    touch /var/citadel-firstboot.done
fi
# ----- END citadel-firstboot -----
FIRSTBOOT
    echo "registered first-boot block in /etc/rc.firsttime"
else
    echo "first-boot block already present, skipped"
fi

# ---- standing note for whoever logs in first ----------------------------
cat > /root/CITADEL_NEXT_STEPS.txt <<'NOTE'
Citadel for OpenBSD 7.9 is installed at /opt/citadel.

First boot already applied the SAFE baseline (sysctls, service minimisation,
doas, ntpd). Log: /var/log/citadel-firstboot.log

Finish the two lockout-capable steps INTERACTIVELY, with a console attached:
  1) review /opt/citadel/site.conf  (EXT_IF, MGMT_CIDRS, ADMIN_USER, ports)
  2) cd /opt/citadel
  3) bin/citadel.sh pf        # load default-deny; auto-reverts in 180s
        then from a NEW session:  bin/citadel.sh pf confirm
  4) bin/citadel.sh ssh       # needs your key already in ~/.ssh/authorized_keys
        then verify a NEW key login before closing the old session
  5) bin/citadel.sh audit
Rollback anytime: bin/citadel.sh rollback
Read first: docs/RECOVERY.md and docs/LIMITS.md
NOTE
chmod 600 /root/CITADEL_NEXT_STEPS.txt
echo "wrote /root/CITADEL_NEXT_STEPS.txt"

echo "=== install.site finished $(date) ==="
} > "$LOG" 2>&1

# Surface the tail on the install console but never fail the OS installation.
tail -5 "$LOG" 2>/dev/null || true
exit 0
