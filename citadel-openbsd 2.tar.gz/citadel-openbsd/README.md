# Citadel for OpenBSD 7.9

一套**默认拒绝、最小权限、可审计、可回滚**的 OpenBSD 服务器纵深防御加固工具包。
它不是"装了就无敌"的软件，而是把 OpenBSD 本身的安全基因（pf、pledge/unveil、
W^X、`securelevel`、安全审计文化）固化成**有失联保护、有备份、有合规审计**的
工程化加固流程。

- 目标系统：**OpenBSD 7.9**（当前稳定版，2026-05-19 发布）
- 语言：纯 POSIX `/bin/sh`（OpenBSD 上是 ksh），无第三方依赖
- 许可证：ISC（宽松许可，可自由商用/修改/再分发）

---

## 它具体做什么

| 层 | 手段 | 对应脚本/配置 |
|---|---|---|
| 网络边界 | 双向默认拒绝 pf；SSH 仅允许白名单 CIDR；暴力破解自动封禁；antispoof + uRPF；scrub | `etc/pf.conf.template` |
| 远程接入 | 仅密钥、仅一个管理员、禁 root/密码/键盘交互；关闭转发/隧道；`sshd -t` 校验后才生效 | `etc/sshd_config.hardened` |
| 内核 | 关闭转发/重定向/源路由/键盘重启/调试器等 sysctl（探测式应用，架构差异自动跳过） | `etc/sysctl.conf.snippet` |
| 服务最小化 | 关闭音响/图形/电源等无关服务，只留 pf/pflog/sshd/ntpd；保留本地 smtpd 收安全日报 | `bin/10-system.sh` |
| 提权 | `doas` 仅授权指定管理员，权限 0600 | `etc/doas.conf.snippet` |
| 时间可信 | OpenNTPD 配 **TLS constraints**，用 HTTPS 证书链时间戳戳穿明文 NTP 欺骗 | `etc/ntpd.conf.snippet` |
| 状态审计 | 只读合规审计，逐项 PASS/WARN/FAIL | `bin/audit.sh` |
| 运行时（可选） | `pledge/unveil`、`securelevel`、磁盘加密、专用用户/chroot——见 `docs/` | — |

---

## 快速开始

> 全程在**目标 OpenBSD 主机**上、通过 `doas`/`su` 以 root 执行。
> 执行前请先读 `docs/RECOVERY.md`（失联恢复）。

```sh
# 0) 准备一个已在 wheel 组、且已验证能用公钥登录的管理员（假设叫 admin）
#    若还没有： adduser（加入 wheel），再把你的公钥放进 ~/.ssh/authorized_keys

# 1) 生成并编辑站点配置
bin/citadel.sh init
vi site.conf
#    必改：EXT_IF（网卡名，ifconfig 查）、MGMT_CIDRS（你的固定 IP/专网 CIDR）、
#          ADMIN_USER、PUBLIC_TCP_PORTS（对外开的端口，管理机可留空）
#    确认有控制台/IPMI/云救援后，把 CONFIRM_OUT_OF_BAND 设为 yes

# 2) 静态自检（可先在任意机器跑，不改动系统）
bin/citadel.sh check

# 3) 系统基线（sysctl、服务、doas、NTP）
bin/citadel.sh system

# 4) 防火墙（默认拒绝，带 180 秒失联自动回滚）
bin/citadel.sh pf
#    → 保留当前会话，另开一个新终端，从白名单地址连入，然后：
bin/citadel.sh pf confirm
#    连不上就静等 180 秒自动还原，或用控制台执行 bin/citadel.sh pf rollback

# 5) SSH 加固（必须先检测到管理员公钥才允许关密码登录）
bin/citadel.sh ssh
#    → 再开一个新终端验证密钥登录 + doas 正常后，才关闭旧会话

# 6) 合规审计
bin/citadel.sh audit
```

任何阶段都支持 `--dry-run`（系统、SSH 阶段）：

```sh
bin/citadel.sh system --dry-run
bin/citadel.sh ssh --dry-run
```

---

## 为什么不会把你锁在门外

1. **防火墙先校验后加载**：`pfctl -nf` 语法不过，绝不改动。
2. **180 秒自动回滚**：新加载的规则若你没在新会话里 `pf confirm`，到期自动还原。
3. **SSH 先验钥后关密码**：检测不到 `authorized_keys` 就拒绝继续。
4. **SSHD 配置先过 `sshd -t`**：不合法的配置不会被安装。
5. **每次改动前自动备份**到 `/var/citadel/backups/<时间戳>/`，可整体回滚：

```sh
bin/citadel.sh rollback            # 回滚到最近一次快照
bin/citadel.sh rollback 20260519T.. # 回滚指定快照
```

---

## 目录结构

```
citadel-openbsd/
├── bin/
│   ├── lib.sh             # 公共函数：备份、校验、模板渲染、pf 片段构建
│   ├── 10-system.sh       # sysctl / 服务最小化 / doas / ntpd
│   ├── 20-pf.sh           # 默认拒绝 pf + 失联自动回滚（apply/confirm/rollback）
│   ├── 30-sshd.sh         # 密钥-only 单管理员 sshd
│   ├── audit.sh           # 只读合规审计
│   ├── unharden.sh        # 从备份快照回滚
│   └── citadel.sh         # 统一入口
├── autoinstall/           # 与 OpenBSD 安装流程融合（装完即带基线）
│   ├── auto_install.conf.template   # 无人值守应答文件
│   ├── install.site.sh              # site79.tgz 内的 /install.site 钩子
│   ├── build-siteset.sh            # 生成 site79.tgz（任意系统可跑）
│   ├── build-bsdrd.sh              # 在 OpenBSD 上重打包定制 bsd.rd
│   └── README-autoinstall.md       # PXE/HTTP/U盘 三种集成方式
├── etc/                   # 配置模板（@TOKEN@ 占位，由 site.conf 渲染）
├── examples/              # 渲染后的配置样例（可直接对照阅读）
├── tests/run_tests.sh     # 40 项静态测试（任意系统可跑，不碰真实系统）
├── site.conf.example
└── docs/
    ├── SECURITY-MODEL.md  # 纵深防御模型与每层依据
    ├── RECOVERY.md        # 失联/误操作恢复手册
    └── LIMITS.md          # 能力边界：它做不到什么
```

---

## 装系统时就融合（autoinstall / 定制 bsd.rd）

除了装完系统再手动跑，也可以让 Citadel 在**安装 OpenBSD 时自动落地**：用官方
`site79.tgz` 自定义文件集 + `/install.site` 钩子，首启自动应用无锁死基线，
应答文件还能内嵌进 `bsd.rd` 实现引导即装。详见 **`autoinstall/README-autoinstall.md`**。

```sh
# 任意系统生成 site79.tgz（OpenBSD 上再 ls -lT > index.txt 即可 HTTP/PXE 发布）
cd autoinstall
ADMIN_USER=ops EXT_IF=em0 MGMT_CIDRS="203.0.113.10/32" sh build-siteset.sh
```

---

## 验证情况

工具包的**模板内容与脚本安全属性**已通过 40 项自动化静态检查（`bin/citadel.sh check`，
已在 Linux 环境实际跑通），覆盖：各脚本语法、默认拒绝/白名单/防暴力破解渲染、
sshd 关键项、脚本里的"先校验后生效/先备份/失联回滚"逻辑。

> 注意：涉及真实 `pfctl`/`sshd`/`rcctl` 的行为只能在 OpenBSD 主机上验证；
> 本仓库**不包含**、也无法在非 OpenBSD 环境替代真机演练。首次请务必保留控制台。

设计依据（官方手册）：`pf.conf(5)`、`sshd_config(5)`、`sysctl.conf(5)`、
`ntpd.conf(5)`（constraints）、`doas.conf(5)`、`rcctl(8)`、`afterboot(8)`、`securelevel(7)`。
