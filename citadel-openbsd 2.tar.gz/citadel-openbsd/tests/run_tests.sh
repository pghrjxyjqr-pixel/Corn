#!/bin/sh
# Static, OS-independent tests for the Citadel kit. Runs on Linux/macOS too:
# validates shell syntax and the security-critical CONTENT of rendered config.
# It never touches a live system.
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
PASS=0; FAIL=0
ok()   { printf 'ok - %s\n' "$1"; PASS=$((PASS+1)); }
bad()  { printf 'not ok - %s\n' "$1"; FAIL=$((FAIL+1)); }

TMP=$(mktemp -d); trap 'rm -rf "$TMP"' EXIT

# --- 1. every shell script parses -----------------------------------------
for f in "$ROOT"/bin/*.sh; do
    if sh -n "$f" 2>"$TMP/err"; then
        ok "syntax: $(basename "$f")"
    else
        bad "syntax: $(basename "$f") :: $(cat "$TMP/err")"
    fi
done

# --- 2. render templates using the real helper ----------------------------
# Sourcing lib.sh is side-effect free at top level (only defines things).
# shellcheck disable=SC1091
. "$ROOT/bin/lib.sh"
# lib.sh defines its own ok(); re-declare our counters after sourcing.
ok()  { printf 'ok - %s\n' "$1"; PASS=$((PASS+1)); }
bad() { printf 'not ok - %s\n' "$1"; FAIL=$((FAIL+1)); }
export EXT_IF="em0" SSH_PORT="22" ADMIN_USER="admin"
export MGMT_CIDRS="198.51.100.7/32 203.0.113.0/24"
export PUBLIC_TCP_PORTS="80 443" ALLOW_OUTBOUND_BASIC="1"
export NTP_CONSTRAINT_URL="https://www.openbsd.org/" SYSLOG_REMOTE=""

# pf: use the SAME fragment builder the stage script uses, then render.
build_pf_fragments
render_template "$ETC_DIR/pf.conf.template" "$TMP/pf.conf"
assemble_pf_blocks "$TMP/pf.conf" "$TMP/pf.conf.out" && mv "$TMP/pf.conf.out" "$TMP/pf.conf"

grep -q '^block in log all' "$TMP/pf.conf" && ok "pf: inbound default deny"      || bad "pf: inbound default deny"
grep -q '^block out log all' "$TMP/pf.conf" && ok "pf: outbound default deny"    || bad "pf: outbound default deny"
grep -q 'table <mgmt>' "$TMP/pf.conf"      && ok "pf: management allowlist table"|| bad "pf: management allowlist table"
grep -q '198.51.100.7/32' "$TMP/pf.conf"   && ok "pf: allowlist CIDR rendered"   || bad "pf: allowlist CIDR rendered"
grep -Eq 'table <mgmt> persist \{[^}]*198\.51\.100\.7/32' "$TMP/pf.conf" && ok "pf: mgmt table carries the CIDR inline" || bad "pf: mgmt table carries the CIDR inline"
grep -q 'overload <bruteforce>' "$TMP/pf.conf" && ok "pf: brute-force overload" || bad "pf: brute-force overload"
grep -q 'antispoof' "$TMP/pf.conf"         && ok "pf: antispoof present"         || bad "pf: antispoof present"
grep -q 'urpf-failed' "$TMP/pf.conf"       && ok "pf: uRPF present"              || bad "pf: uRPF present"
grep -q 'port 22' "$TMP/pf.conf"           && ok "pf: ssh port rendered"         || bad "pf: ssh port rendered"
if grep -q 'pass .* from any to .*port 22' "$TMP/pf.conf"; then bad "pf: ssh open to any"; else ok "pf: ssh not open to any"; fi
grep -Eq '^table <mgmt> persist \{ 198.51.100.7/32 203.0.113.0/24 \}' "$TMP/pf.conf" \
    && ok "pf: allowlist actually rendered on table line" || bad "pf: allowlist actually rendered on table line"
grep -q 'port { 80 443 }' "$TMP/pf.conf" && ok "pf: public ports rendered" || bad "pf: public ports rendered"

# --- 3. sshd rendered content ---------------------------------------------
render_template "$ETC_DIR/sshd_config.hardened" "$TMP/sshd_config"
for needle in 'PermitRootLogin no' 'PasswordAuthentication no' \
              'PermitEmptyPasswords no' 'KbdInteractiveAuthentication no' \
              'PubkeyAuthentication yes' 'AllowTcpForwarding no' \
              'AllowUsers admin' 'MaxAuthTries 3' 'AuthenticationMethods publickey'; do
    grep -qF "$needle" "$TMP/sshd_config" && ok "sshd: $needle" || bad "sshd: $needle"
done
if grep -qi '^[[:space:]]*UsePAM' "$TMP/sshd_config"; then bad "sshd: must not contain an active UsePAM line"; else ok "sshd: no active PAM keyword"; fi

# --- 4. sysctl / ntp / doas content ---------------------------------------
grep -q '^net.inet.ip.forwarding=0' "$ETC_DIR/sysctl.conf.snippet" && ok "sysctl: forwarding off" || bad "sysctl: forwarding off"
grep -q '^machdep.kbdreset=0'      "$ETC_DIR/sysctl.conf.snippet" && ok "sysctl: kbdreset off"    || bad "sysctl: kbdreset off"
grep -q '^constraints from'        "$ETC_DIR/ntpd.conf.snippet"   && ok "ntp: TLS constraint"     || bad "ntp: TLS constraint"
render_template "$ETC_DIR/doas.conf.snippet" "$TMP/doas.conf"
grep -q '^permit persist admin as root' "$TMP/doas.conf" && ok "doas: admin-only" || bad "doas: admin-only"

# No rendered config may still contain an unfilled @TOKEN@.
if grep -lE '@[A-Z_]+@' "$TMP"/pf.conf "$TMP"/sshd_config "$TMP"/doas.conf >/dev/null 2>&1; then
    bad "rendered configs contain unfilled placeholders"; grep -nE '@[A-Z_]+@' "$TMP"/* || true
else
    ok "no unfilled placeholders in rendered configs"
fi

# --- 5. safety properties of the stage scripts ----------------------------
grep -q "sshd -t" "$ROOT/bin/30-sshd.sh" && ok "ssh stage validates before install" || bad "ssh stage validates before install"
grep -q "authorized_keys" "$ROOT/bin/30-sshd.sh" && ok "ssh stage requires a key first" || bad "ssh stage requires a key first"
grep -q "pfctl -nf" "$ROOT/bin/20-pf.sh" && ok "pf stage syntax-checks first" || bad "pf stage syntax-checks first"
grep -q "AUTO-ROLLBACK" "$ROOT/bin/20-pf.sh" && ok "pf stage has timed auto-rollback" || bad "pf stage timed auto-rollback"
grep -q "CONFIRM_OUT_OF_BAND" "$ROOT/bin/20-pf.sh" && ok "pf stage requires out-of-band ack" || bad "pf stage out-of-band ack"
grep -q "backup_file" "$ROOT/bin/10-system.sh" && ok "system stage backs up before change" || bad "system stage backup"

printf '\n%d passed, %d failed\n' "$PASS" "$FAIL"
[ "$FAIL" -eq 0 ]
