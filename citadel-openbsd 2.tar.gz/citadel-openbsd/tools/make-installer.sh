#!/bin/sh
# make-installer.sh - build a single self-extracting citadel-installer.sh
# that embeds the whole kit (tar.gz, base64). The resulting file needs only
# a stock OpenBSD (base64, tar, awk, sh) - no network, no package required.
set -eu

HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
KIT=$(CDPATH= cd -- "$HERE/.." && pwd)          # .../citadel-openbsd
PARENT=$(CDPATH= cd -- "$KIT/.." && pwd)        # the folder containing it
BASENAME=$(basename "$KIT")                     # citadel-openbsd
OUT="${1:-$PARENT/citadel-installer.sh}"
MARK='__CITADEL_PAYLOAD__'

# ---- installer header (everything before the marker) ---------------------
cat > "$OUT" <<'HEADER'
#!/bin/sh
# =============================================================================
# Citadel for OpenBSD 7.9 - self-extracting installer (single file, offline)
#
# Usage on the target OpenBSD host:
#     sh citadel-installer.sh [--prefix DIR] [--check-only]
#
#   (no args)     extract the kit to ./citadel-openbsd and run the static check
#   --prefix DIR  extract into DIR instead of ./citadel-openbsd
#   --check-only  extract to a temp dir, run the check, then remove it
#
# It only EXTRACTS and VERIFIES. It never changes your system: after editing
# site.conf you run the numbered stages yourself (see the printed next steps).
# Stock tools only: sh, awk, base64, tar (all in OpenBSD base).
# =============================================================================
set -u

PREFIX=""
CHECK_ONLY=0
while [ $# -gt 0 ]; do
    case "$1" in
        --prefix)     shift; PREFIX="${1:-}" ;;
        --check-only) CHECK_ONLY=1 ;;
        --prefix=*)   PREFIX="${1#--prefix=}" ;;
        *) printf 'unknown option: %s\n' "$1" >&2; exit 2 ;;
    esac
    shift || true
done

SELF=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)/$(basename -- "$0")
[ -f "$SELF" ] || SELF="$0"

WORK=$(mktemp -d /tmp/citadel.XXXXXX) || { echo "mktemp failed" >&2; exit 1; }
cleanup() { [ "$CHECK_ONLY" = "1" ] && rm -rf "$WORK"; }
trap cleanup EXIT INT TERM

printf '==> Extracting embedded kit...\n'
awk 'found{print} /^__CITADEL_PAYLOAD__$/{found=1}' "$SELF" \
    | base64 -d | tar xzf - -C "$WORK" || {
        echo "extraction failed (corrupt/truncated file?)" >&2; exit 1; }

SRCDIR="$WORK/citadel-openbsd"
[ -f "$SRCDIR/bin/citadel.sh" ] || { echo "payload layout unexpected" >&2; exit 1; }

printf '==> Running static self-check...\n'
if sh "$SRCDIR/tests/run_tests.sh" >"$WORK/check.out" 2>&1; then
    tail -1 "$WORK/check.out"
else
    cat "$WORK/check.out" >&2
    echo "self-check FAILED - kit not installed." >&2
    exit 1
fi

if [ "$CHECK_ONLY" = "1" ]; then
    printf '==> --check-only: integrity verified, temp copy removed.\n'
    exit 0
fi

if [ -z "$PREFIX" ]; then PREFIX="$PWD/citadel-openbsd"; fi
if [ -e "$PREFIX" ]; then
    printf 'Target %s already exists; leaving extracted copy at:\n  %s\n' "$PREFIX" "$SRCDIR" >&2
    printf 'Move it manually after review, or rerun with --prefix to an empty path.\n' >&2
    exit 0
fi
( CDPATH= cd -- "$(dirname -- "$PREFIX")" 2>/dev/null || mkdir -p "$(dirname -- "$PREFIX")" )
mkdir -p "$(dirname -- "$PREFIX")"
mv "$SRCDIR" "$PREFIX"

cat <<EOF

==> Citadel installed to: $PREFIX

NEXT STEPS (run on OpenBSD, as root via doas/su; keep a console attached)
  1) cd $PREFIX
  2) cp site.conf.example site.conf  &&  vi site.conf
       set EXT_IF, MGMT_CIDRS (your fixed IP/VPN CIDR), ADMIN_USER, PUBLIC_TCP_PORTS
       set CONFIRM_OUT_OF_BAND=yes once console/rescue access is ready
  3) bin/citadel.sh system     # sysctls, service minimisation, doas, NTP
  4) bin/citadel.sh pf         # then, from a NEW session: bin/citadel.sh pf confirm
  5) bin/citadel.sh ssh        # verify a NEW key login before closing the old one
  6) bin/citadel.sh audit
  Rollback any time: bin/citadel.sh rollback
  Read first: docs/RECOVERY.md and docs/LIMITS.md
EOF
exit 0

# ===== do not edit below this line - appended payload =====
HEADER

printf '%s\n' "$MARK" >> "$OUT"
( CDPATH= cd -- "$PARENT" && tar -czf - "$BASENAME" ) | base64 >> "$OUT"
chmod +x "$OUT"
printf 'built %s (%s bytes)\n' "$OUT" "$(wc -c < "$OUT")"
