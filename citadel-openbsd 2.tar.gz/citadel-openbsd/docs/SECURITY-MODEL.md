# 安全模型（Defense in Depth）

Citadel 的原则：**假设外层已被突破，让每一层仍然独立成立**。不依赖单一机制，
也不相信"改一个配置就安全"。

## 分层与依据

1. **采购/安装层 — 可验证的系统**
   - 只从官方渠道安装 OpenBSD 7.9，安装后 `syspatch` 打满官方二进制补丁。
   - OpenBSD base 系统大多数服务默认关闭、多数守护进程内置 pledge/unveil。

2. **磁盘与引导（建议手动启用，工具包不强制）**
   - 全盘加密：`bioctl(8)` + softraid 加密卷；物理/云主机失盗时数据不泄露。
   - 启动后 `syspatch` 才能持续：把"补丁窗口"纳入运维流程。

3. **网络边界 — pf 默认拒绝**
   - `block in log all` + `block out log all`，双向默认拒绝，仅放通具名流量。
   - 出方向也默认拒绝：主机被植入后门时，外连 C2、数据外传都被阻断。
   - 管理 SSH 只允许 `<mgmt>` 白名单 CIDR；`overload <bruteforce>` 把高频
     失败来源自动移入封禁表；`antispoof` + `urpf-failed` 挡伪造源地址。
   - 注意：出站放行 DNS/NTP/HTTP(S)/ICMP 仅为打补丁与时间同步所需；
     纯内网设备可把 `ALLOW_OUTBOUND_BASIC` 设为 0。

4. **远程接入 — OpenSSH 最小授权**
   - 仅公钥、仅一个 `AllowUsers`、禁 root/密码/键盘交互/主机信任。
   - 关 X11/Agent/TCP 转发与隧道，防止这台管理机被当成跳板。
   - `MaxAuthTries 3`、`LoginGraceTime 30` 收窄攻击窗口。
   - 更强的算法钉死放在模板注释里——**先验证所有客户端再启用**，避免连不上。

5. **内核攻击面 — sysctl**
   - 关 IP 转发/重定向/源路由/定向广播，不做路由器就不具备路由器弱点。
   - `machdep.kbdreset=0` 防止 Ctrl-Alt-Esc 直接进调试器；`ddb.panic=0`、
     `ddb.console=0`、`kern.allowkmem=0` 收窄本机/调试攻击面。
   - 每一项都先 `sysctl -n <key>` 探测，架构不支持的键自动跳过，不会写坏配置。

6. **服务最小化 + 提权**
   - 关闭 sndiod/xenodm/apmd 等与网络服务无关的守护进程。
   - `doas` 只授权指定管理员（`permit persist <admin> as root`），文件 0600。
   - 保留本地 smtpd（仅监听 localhost，pf 照样挡 25 端口），因为 OpenBSD
     每夜 `security(8)` 报告靠本地邮件送达 root。

7. **时间完整性 — NTP TLS constraints**
   - 明文 NTP 可被中间人篡改时间，进而让证书/TOTP/日志时序失效。
   - ntpd 的 `constraints from https://...` 要求 NTP 时间与 TLS 证书链时间一致，
     显著抬高时间攻击门槛。

8. **运行时最小权限（生态层面，见 LIMITS.md）**
   - OpenBSD base 的 httpd/smtpd/ntpd 等已内置 pledge/unveil；
   - 对第三方服务，用**专用低权限用户 + chroot/文件系统策略 + pf** 隔离，
     因为 pledge/unveil 无法从外部强加给未改写的程序。

9. **检测与审计**
   - `audit.sh` 只读核对生效状态（不是只看配置文件）：`sshd -T`、`pfctl -s`、
     `sysctl -n`、`rcctl get`、补丁状态、UID0 账户等。
   - 被丢弃的包进 `pflog0`，可用 `tcpdump -nettti pflog0` 复盘。

## 关键工程纪律

- **先备份、先校验、后生效**；危险动作显式确认。
- **失联可自愈**：pf 180 秒自动回滚，不用赌网络。
- **可重复执行（幂等）**：sysctl 去重写入、服务状态可反复套用。
- **最小化是持续过程**：新端口、新服务必须显式加入，默认一律不通。
