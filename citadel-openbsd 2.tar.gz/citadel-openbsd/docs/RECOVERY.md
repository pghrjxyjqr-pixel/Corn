# 失联与误操作恢复手册

**动手前请确保至少有一条不依赖 SSH/网络的通道**：物理串口/控制台、IPMI/iDRAC、
虚拟机串口、或云厂商的 VNC/救援模式。这是 `CONFIRM_OUT_OF_BAND=yes` 的意义。

## 1. 防火墙把自己挡在外面

- **最省事**：什么都不用做。`20-pf.sh` 加载新规则后启动了 180 秒看护进程，
  你不在新会话里 `confirm`，到期自动恢复为上一个"已知良好"规则集。
- **控制台手动回滚**（有控制台时）：
  ```sh
  bin/citadel.sh pf rollback
  # 或直接
  pfctl -f /var/citadel/pf.conf.last-known-good
  ```
- **知道自己该在白名单但被封禁表误伤**：控制台执行 `pfctl -t bruteforce -T flush`，
  并核对 `site.conf` 的 `MGMT_CIDRS`。
- **规则冻结在 securelevel 2**：见第 4 节，需重启到单用户模式处理。

## 2. SSH 配错 / 密钥不工作

- 当前会话**不要关**，另开终端测试；脚本 reload sshd 不会断已有连接。
- 从备份恢复：
  ```sh
  cp /var/citadel/backups/<时间戳>/etc/ssh/sshd_config /etc/ssh/sshd_config
  rcctl reload sshd
  ```
- 若所有会话都断了：用控制台登录后恢复备份，或临时 `rcctl set sshd flags` 不解决
  配置问题——优先恢复配置文件。

## 3. 系统阶段后异常

- 回滚该阶段改动过的全部文件：
  ```sh
  bin/citadel.sh rollback <时间戳>
  ```
- 注意：已经生效的运行时 sysctl 不会自动全部逆向（少数只能重启复位），
  必要时重启以回到 `/etc/sysctl.conf` 记录的状态。

## 4. securelevel 2 导致 pf/文件改不动

securelevel 2 会在运行期冻结 pf 规则、阻止写裸盘、禁止改不可变标志，直到下次启动。
处理方式只能是**重启进入单用户模式**（`boot -s`），在 securelevel 提升前修改：
文件用 `chflags noschg <file>` 去不可变，改完正常重启。因此默认**不启用** level 2，
除非你已演练过这套维护流程。

## 5. 发现系统可能已被入侵

加固包用于**预防**和**基线核对**，不是取证/清除工具。怀疑失陷时：
1. 不要相信本机命令；从外部/带外观察网络。
2. 保留磁盘镜像做取证，勿直接关机覆盖证据（视合规要求）。
3. 用已知干净的安装介质重装、恢复离线备份、轮换全部凭据/密钥。
4. 用 `audit.sh` 只是辅助定位，不能证明"干净"。

## 6. 备份位置

所有改动前的原始文件都在 `/var/citadel/backups/<UTC时间戳>/`，含 `MANIFEST`
记录改了哪些文件。请把你的**业务数据备份**放在别处（见 LIMITS.md），加固包的
配置备份不能替代数据备份。
